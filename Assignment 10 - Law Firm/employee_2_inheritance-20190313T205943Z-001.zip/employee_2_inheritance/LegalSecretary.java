// A class to represent legal secretaries.
public class LegalSecretary extends Employee {
    public void fileLegalBriefs() {
        System.out.println("I could file all day!");
    }

    public void showSalary() {
        System.out.println("My salary is $45,000.");
    }
}
