// A class to represent marketers.
public class Marketer extends Employee {
    public void advertise() {
        System.out.println("Act now, while supplies last!");
    }

    public void showSalary() {
        System.out.println("My salary is $50,000.");
    }
}
