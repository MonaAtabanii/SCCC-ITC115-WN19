// A class to represent lawyers.
public class Lawyer extends Employee {
    public void applyForVacation() {
        System.out.println("Use the pink vacation form.");
    }
    
    public void showVacation() {
        System.out.println("I receive 3 weeks vacation.");
    }

    public void sue() {
        System.out.println("I'll see you in court!");
    }
}
